# NBIS & NGI Hi-C curation workshop -- Anna's hummingbird example

Remi-Andre Olsen (<remi-andre.olsen@scilifelab.se>)

All raw data is publically available from the VGP project: https://vgp.github.io/genomeark/Calypte_anna/
See: VGP/download_data.txt 

## Software

* Juicer v. 1.6 (docker://remiolsen/juicer-cpu-docker:20211125) 
* 3D-DNA (docker://remiolsen/3d-dna-docker:20211125) 
* Salsa2 v. 2.3 (bioconda: 2.3--py27hee3b9ab_0)  
* rapid-curation, https://gitlab.com/wtsi-grit/rapid-curation (git-rev b670f1712025b9814629424cfecd9093144bedb8)
* merged_nodups2bed (docker://remiolsen/merged_nodups2bed:20220513)

## Files

### Output draft assemblies

* 03-salsa2/scaffolds/scaffolds_FINAL.fasta
* 05-3DDNA/pac_fcnz_hap1_scaff10x.FINAL.fasta 

### Juicer pairs "mnd" file 

* 01-juicer/aligned_clean/merged_nodups.txt

### 3D-DNA rawchrom (input for JBAT curation)

* 05-3DDNA/pac_fcnz_hap1_scaff10x.rawchrom.assembly  
* 05-3DDNA/pac_fcnz_hap1_scaff10x.rawchrom.hic

### Pretextview and HiGlass files (Salsa2 assemblies)

* 04-rapid_curation/bCalAnn.annotated.pretext
* 04-rapid_curation/bCalAnn.mcool

