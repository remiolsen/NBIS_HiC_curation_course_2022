#!/bin/bash -l
#SBATCH -A ngi2016004
#SBATCH -o rc_add_annotation.out
#SBATCH -e rc_add_annotation.err
#SBATCH -J rc_add_annotation_bcalAnn.job
#SBATCH -p core -n 2
#SBATCH -t 1-00:00:00
#SBATCH --mail-user remi-andre.olsen@scilifelab.se 
#SBATCH --mail-type=ALL
#SBATCH --qos=normal

# singularity pull docker://remiolsen/rapidcuration_extras:20220629
re="singularity exec /vulpes/proj/ngis/ngi2016004/private/remi/singularity_images/rapidcuration_extras_20220629.sif"
outprefix="bCalAnn"
ref=/vulpes/proj/ngis/ngi2016004/private/remi/analysis/NBIS_HiC_curation_course/04-rapid_curation/in_ref/scaffolds_FINAL.fasta

# git clone https://gitlab.com/wtsi-grit/rapid-curation.git
# Note 2022-02-25. These scripts might contain some hardcoded paths that need to be manually edited.
rc=/proj/ngis/ngi2016004/private/remi/opt/rapid-curation/

## Note! this file is more of a cookbook than a script or a pipeline.
## Use with caution and read the rapid curation documentation first

# 1) Add annotations to pretextview file
annotation_folder=/vulpes/proj/ngis/ngi2016004/private/remi/analysis/NBIS_HiC_curation_course/04-rapid_curation

$re bigWigToBedGraph ${annotation_folder}/${outprefix}.coverage.bw /dev/stdout | $re PretextGraph -i ${annotation_folder}/${outprefix}.pretext -n "coverage" -o ${outprefix}.annotated.pretext
$re bigWigToBedGraph ${annotation_folder}/${outprefix}.repeat_density.bw /dev/stdout | $re PretextGraph -i ${outprefix}.annotated.pretext -n "repeat density" 
cat ${annotation_folder}/${outprefix}.gap.bedgraph | $re PretextGraph -i ${outprefix}.annotated.pretext -n "gaps"
cat ${annotation_folder}/${outprefix}.telomere.bedgraph | $re PretextGraph -i ${outprefix}.annotated.pretext -n "telomeres"
