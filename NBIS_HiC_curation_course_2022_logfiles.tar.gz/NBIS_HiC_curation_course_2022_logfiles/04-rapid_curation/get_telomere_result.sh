cat $1|awk '{print $2"\t"$4"\t"$5}'|sed 's/>//g' > $2
cat $1|awk '{print $2"\t"$4"\t"$5"\t"$6}'|sed 's/>//g' > $3
