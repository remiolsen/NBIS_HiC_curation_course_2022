#!/bin/bash

if [ -z $1 ]; then
	echo "Usage: ./find_telomere.sh <fasta>"
	exit -1
fi


file=$1
telomereSeq=$2
out_dir=$3
file_name=`basename $file`

if [ ! -e $file_name ]; then
	ln -s $file
fi

file=$file_name
prefix=`echo $file | sed 's/.fasta$//g' | sed 's/.fa$//g'`


./find_telomere $file $telomereSeq > $out_dir/$prefix.telomere
java -Xms1g -Xmx1g -cp ./telomere.jar FindTelomereWindows $out_dir/$prefix.telomere 99.9 > $out_dir/$prefix.windows
cat $out_dir/$prefix.windows |awk '{if ($4 > 100000 && $3-$5 > 100000) print $0}'


